class student:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def print_info(self):
        print(f"name:{self.name} age：{self.age}")

print("hello world")
